import os
import json
import requests
from flask import Flask, render_template, request, redirect, url_for, session
from datetime import datetime
from dotenv import load_dotenv

# ---------- Fix: Clear proxy to avoid PythonAnywhere blocking ----------
os.environ['HTTP_PROXY'] = ''
os.environ['HTTPS_PROXY'] = ''

load_dotenv('config.env')

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'dev-key-change-me')

# ---------- Absolute path for data file ----------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE_DIR, 'data', 'products.json')

PAYLIO_API_KEY = os.getenv('PAYLIO_API_KEY')
PAYLIO_WALLET = os.getenv('PAYLIO_WALLET')
PAYLIO_API_URL = 'https://paylio.org/api/v1/wallet'

MARKUP_RATE = float(os.getenv('MARKUP_RATE', 1.6))
TAX_RATE = float(os.getenv('TAX_RATE', 0.10))
FREE_SHIPPING_THRESHOLD = float(os.getenv('FREE_SHIPPING_THRESHOLD', 75))

# ---------- Allowed product types (only these will appear) ----------
ALLOWED_TYPES = [
    'Vape',
    'Edible',
    'Pre-roll',
    'Delta Vape',
    'Delta 8',
    'THC-A',
    'THC-P',
    'Cartridge',
    'Disposable',
    'Gummies',
    'Concentrate',
    'Flower',
    'Cleaner'  # if you want the Cookies device, keep it
]

# ---------- Load Products + Inject Test Product ----------
def load_products():
    # Load from JSON
    try:
        with open(DATA_FILE, 'r') as f:
            data = json.load(f)
        products = data.get('products', [])
    except (FileNotFoundError, json.JSONDecodeError):
        products = []

    # Filter: only keep products with allowed types
    products = [p for p in products if p.get('product_type') in ALLOWED_TYPES]

    # Add a test product for payment testing (wholesale $0.01 → retail ~$0.02)
    test_product = {
        "id": 999999,
        "title": "🧪 Test Product (1¢ wholesale)",
        "handle": "test-product",
        "body_html": "<p>This is a test product for payment testing. Price is $0.02 after markup.</p>",
        "published_at": "2026-01-01T00:00:00-00:00",
        "created_at": "2026-01-01T00:00:00-00:00",
        "updated_at": "2026-01-01T00:00:00-00:00",
        "vendor": "Test",
        "product_type": "Vape",
        "tags": ["test"],
        "variants": [
            {
                "id": 999999001,
                "title": "Test Variant",
                "option1": "Test Variant",
                "option2": None,
                "option3": None,
                "sku": "TEST001",
                "requires_shipping": True,
                "taxable": True,
                "featured_image": None,
                "available": True,
                "price": "0.01",          # wholesale price
                "grams": 10,
                "compare_at_price": None,
                "position": 1,
                "product_id": 999999,
                "created_at": "2026-01-01T00:00:00-00:00",
                "updated_at": "2026-01-01T00:00:00-00:00"
            }
        ],
        "images": [],
        "options": [
            {"name": "Title", "position": 1, "values": ["Test Variant"]}
        ]
    }
    products.append(test_product)

    # Apply markup and compute fields
    for p in products:
        for v in p['variants']:
            v['retail_price'] = round(float(v['price']) * MARKUP_RATE, 2)
        p['min_retail'] = min(v['retail_price'] for v in p['variants'])
        p['has_stock'] = any(v['available'] for v in p['variants'])
    return products

PRODUCTS = load_products()

def get_product(product_id):
    for p in PRODUCTS:
        if p['id'] == product_id:
            return p
    return None

def get_variant(product, variant_id):
    for v in product['variants']:
        if v['id'] == variant_id:
            return v
    return None

# ---------- Cart Helpers ----------
def get_cart():
    return session.get('cart', [])

def set_cart(cart):
    session['cart'] = cart

def add_to_cart(product_id, variant_id, quantity=1):
    cart = get_cart()
    for item in cart:
        if item['variant_id'] == variant_id:
            item['quantity'] += quantity
            set_cart(cart)
            return
    product = get_product(product_id)
    variant = get_variant(product, variant_id)
    cart.append({
        'product_id': product_id,
        'variant_id': variant_id,
        'product_title': product['title'],
        'variant_title': variant['title'],
        'price': variant['retail_price'],
        'weight': variant['grams'],
        'image': product['images'][0]['src'] if product['images'] else '',
        'quantity': quantity
    })
    set_cart(cart)

def remove_from_cart(variant_id):
    cart = get_cart()
    cart = [item for item in cart if item['variant_id'] != variant_id]
    set_cart(cart)

def update_cart(variant_id, quantity):
    cart = get_cart()
    for item in cart:
        if item['variant_id'] == variant_id:
            if quantity <= 0:
                cart.remove(item)
            else:
                item['quantity'] = quantity
            break
    set_cart(cart)

def clear_cart():
    session.pop('cart', None)

def get_cart_summary():
    cart = get_cart()
    subtotal = sum(item['price'] * item['quantity'] for item in cart)
    weight = sum(item['weight'] * item['quantity'] for item in cart)

    if subtotal >= FREE_SHIPPING_THRESHOLD:
        shipping = 0
    elif weight < 100:
        shipping = 4.99
    elif weight < 500:
        shipping = 7.99
    elif weight < 1000:
        shipping = 11.99
    else:
        shipping = 14.99

    tax = subtotal * TAX_RATE
    total = subtotal + shipping + tax

    return {
        'cart_items': cart,
        'subtotal': subtotal,
        'shipping': shipping,
        'tax': tax,
        'total': total,
        'weight': weight
    }

# ---------- Routes ----------
@app.route('/')
def index():
    type_filter = request.args.get('type', '')
    vendor_filter = request.args.get('vendor', '')
    in_stock = request.args.get('in_stock') == 'on'
    sort = request.args.get('sort', 'name')

    filtered = PRODUCTS[:]
    if type_filter:
        filtered = [p for p in filtered if p['product_type'] == type_filter]
    if vendor_filter:
        filtered = [p for p in filtered if p['vendor'] == vendor_filter]
    if in_stock:
        filtered = [p for p in filtered if p['has_stock']]

    if sort == 'name':
        filtered.sort(key=lambda p: p['title'].lower())
    elif sort == 'name_desc':
        filtered.sort(key=lambda p: p['title'].lower(), reverse=True)
    elif sort == 'price':
        filtered.sort(key=lambda p: p['min_retail'])
    elif sort == 'price_desc':
        filtered.sort(key=lambda p: p['min_retail'], reverse=True)
    elif sort == 'newest':
        filtered.sort(key=lambda p: p['created_at'], reverse=True)

    types = sorted({p['product_type'] for p in PRODUCTS if p['product_type']})
    vendors = sorted({p['vendor'] for p in PRODUCTS if p['vendor']})

    return render_template('index.html',
                           products=filtered,
                           types=types,
                           vendors=vendors)

@app.route('/product/<int:product_id>')
def product(product_id):
    product = get_product(product_id)
    if not product:
        return "Product not found", 404
    selected = next((v for v in product['variants'] if v['available']), product['variants'][0])
    return render_template('product.html', product=product, selected_variant=selected)

@app.route('/add-to-cart', methods=['POST'])
def add_to_cart_route():
    product_id = int(request.form['product_id'])
    variant_id = int(request.form['variant_id'])
    add_to_cart(product_id, variant_id, 1)
    return redirect(url_for('cart'))

@app.route('/cart')
def cart():
    summary = get_cart_summary()
    return render_template('cart.html', **summary)

@app.route('/update-cart', methods=['POST'])
def update_cart_route():
    variant_id = int(request.form['variant_id'])
    quantity = int(request.form['quantity'])
    update_cart(variant_id, quantity)
    return redirect(url_for('cart'))

@app.route('/remove-from-cart', methods=['POST'])
def remove_from_cart_route():
    variant_id = int(request.form['variant_id'])
    remove_from_cart(variant_id)
    return redirect(url_for('cart'))

@app.route('/checkout', methods=['GET', 'POST'])
def checkout():
    summary = get_cart_summary()
    if not summary['cart_items']:
        return redirect(url_for('cart'))

    if request.method == 'GET':
        return render_template('checkout.html', **summary)

    # POST: Create PayLio checkout
    name = request.form['name']
    email = request.form['email']
    address = request.form['address']
    city = request.form['city']
    state = request.form['state']
    zip_code = request.form['zip']
    country = request.form['country']

    callback_url = url_for('paylio_callback', _external=True)

    payload = {
        'address': PAYLIO_WALLET,
        'callback': callback_url,
        'amount': f"{summary['total']:.2f}",
        'currency': 'USD',
        'passFeeToCustomer': True,
        'email': email,
        'note': f"Order from {name} - {address}, {city}, {state} {zip_code}, {country}"
    }

    headers = {
        'Authorization': f'Bearer {PAYLIO_API_KEY}',
        'Content-Type': 'application/json'
    }

    try:
        # Explicitly disable proxies to avoid PythonAnywhere blocking
        response = requests.post(PAYLIO_API_URL, json=payload, headers=headers, proxies={})
        response.raise_for_status()
        data = response.json()

        session['pending_order'] = {
            'payment_id': data.get('payment_id'),
            'ipn_token': data.get('ipn_token'),
            'customer': {
                'name': name,
                'email': email,
                'address': f"{address}, {city}, {state} {zip_code}, {country}"
            },
            'cart': summary['cart_items'],
            'subtotal': summary['subtotal'],
            'shipping': summary['shipping'],
            'tax': summary['tax'],
            'total': summary['total']
        }

        return redirect(data['checkout_url'])

    except requests.exceptions.RequestException as e:
        return f"PayLio error: {str(e)}", 500

@app.route('/paylio-callback')
def paylio_callback():
    status = request.args.get('status')
    payment_id = request.args.get('payment_id')

    if status == 'paid':
        pending = session.get('pending_order', {})
        if pending and pending.get('payment_id') == payment_id:
            order_data = {
                'id': payment_id,
                'customer': pending['customer'],
                'items': pending['cart'],
                'subtotal': pending['subtotal'],
                'shipping': pending['shipping'],
                'tax': pending['tax'],
                'total': pending['total'],
                'status': 'paid',
                'created_at': datetime.utcnow().isoformat()
            }

            try:
                with open('orders.json', 'r') as f:
                    orders = json.load(f)
            except (FileNotFoundError, json.JSONDecodeError):
                orders = []

            orders.append(order_data)
            with open('orders.json', 'w') as f:
                json.dump(orders, f, indent=2)

            clear_cart()
            session.pop('pending_order', None)

            return render_template('order_confirmation.html',
                                   order_id=payment_id,
                                   customer_email=pending['customer']['email'])

    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)