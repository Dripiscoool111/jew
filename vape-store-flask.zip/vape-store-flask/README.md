# Vape Store – Flask + PayLio

Full e‑commerce store with Bootstrap 5, mobile‑first, and PayLio crypto payments.

## Setup
1. Replace `data/products.json` and `data/products2.json` with your product data.
2. `config.env` already has your PayLio credentials.
3. Install: `pip install -r requirements.txt`
4. Run: `python app.py`

## Deploy 24/7
- **PythonAnywhere**: Upload folder → create Flask web app → set environment variables → reload.
- **Render**: Connect your GitHub repo – auto‑deploy.
